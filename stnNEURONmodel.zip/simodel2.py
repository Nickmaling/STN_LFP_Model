import sys
import os
import numpy as np
import struct

#os.chdir('/home/ngm40/scott')
#sys.path.append('/home/ngm40/scott')

from numpy import arange,array,sort,zeros
from random import gauss,seed,jumpahead
from math import sqrt
from scipy.stats import truncnorm

del os.environ['DISPLAY']

from neuron import h
from classes.Cell import STN
from classes.Synapse import AMPA,GABAa,sec_rtype
from mytools.rec_dict import rec_dict

h.load_file("stdrun.hoc")
h.cvode_active(0)
h.steps_per_ms=100
h.dt=0.01

steps_per_ms = 100
fs_NEURON=steps_per_ms*1e3
fs_LFP=1e3
downsample=fs_NEURON/fs_LFP
sim_length=1.0e3
tstart=0.5e3
tstop = tstart + sim_length

h.tstop = tstop
start = tstart * steps_per_ms
stop = tstop * steps_per_ms

osc_freq = np.random.exponential(20,1)
delta_syn = (1e3)/osc_freq
synstart = 300
delta_IPSP = delta_syn/2
nsyninputs = 40
noise = 0.01
sigma_cell = 6.25

tbound = 2
sigma_syn = sqrt(sigma_cell)

cell = STN()
cell.retrieve_coordinates(h.soma[1])

recording_dict=dict()
location = 0.5
variable = 'i_membrane'

for sec in cell.get_secs():
    rec_dict(recording_dict,sec,location,variable)
cell.record(recording_dict)
GABAa_secs,AMPA_secs = sec_rtype(cell,cell.root,100)
gabaa,ampa = list(),list()
for sec in GABAa_secs:
    gabaa.append(GABAa(sec))
for sec in AMPA_secs:
    ampa.append(AMPA(sec))

esyntimes = arange(synstart,synstart+(delta_syn*nsyninputs),delta_syn)
isyntimes = esyntimes+delta_IPSP

erand_cell = truncnorm.rvs(-tbound,tbound,size=len(esyntimes))*sigma_cell
irand_cell = truncnorm.rvs(-tbound,tbound,size=len(isyntimes))*sigma_cell

eesyntimes,iisyntimes=zeros([len(esyntimes),1]),zeros([len(isyntimes),1])
for i in xrange(len(esyntimes)):
    eesyntimes[i] = esyntimes[i]+round(erand_cell[i]*steps_per_ms)*1/steps_per_ms  #add temporal jitter to input times at individual synapses (see Pettersen et al., 2008)

for i in xrange(len(isyntimes)):
    iisyntimes[i] = isyntimes[i]+round(irand_cell[i]*steps_per_ms)*1/steps_per_ms

for i in xrange(len(ampa)):
    etemp=list()
    for j in xrange(len(eesyntimes)):
        etemp.append(float(int(round((eesyntimes[j]+gauss(0,sigma_syn))*steps_per_ms)))*1/steps_per_ms)
    eeesyntimes = list(set(etemp))
    ampa[i].VecStim(sort(array(eeesyntimes)))

for i in xrange(len(gabaa)):
    itemp=list()
    for j in xrange(len(iisyntimes)):
        itemp.append(float(int(round((iisyntimes[j]+gauss(0,sigma_syn))*steps_per_ms)))*1/steps_per_ms)
    iiisyntimes = list(set(itemp))
    gabaa[i].VecStim(sort(array(iiisyntimes)))

h.init()
h.fcurrent()
h.run()

cell.store(True)    #returns recording dictionary as a global variable
data = cell.arrays

a=array([1.000000000000000,-3.991202360304754,5.973646395437279,-3.973685706502324,0.991241671369955])
b=array([0.096304518310686,0.0,-0.192609036621373,0.0,0.096304518310686])*1.0e-4
n=4+1 #n-1 = order of filter

secs = cell.get_secs()
rows = (tstop - tstart) * steps_per_ms / downsample     #number of rows
cols = len(secs)    #number of columns in matrix containing membrane currents
i_mat = np.zeros([rows,cols])   #initialize matrix to contain membrane currents for each individual compartment
jj = 0
t = data['t'][range(int(start),int(stop),int(downsample))]-tstart #ms, time vector
for sec in secs:
    im_temp=data[sec.name()+'(0.5).i_membrane'][:]*h.area(0.5,sec=sec)*1e-11
    x = im_temp
    y = np.zeros(np.shape(x))
    y[1-1]=b[1-1]*x[1-1]
    y[2-1]=b[1-1]*x[2-1]+b[2-1]*x[1-1]-a[2-1]*y[1-1]
    y[3-1]=b[1-1]*x[3-1]+b[2-1]*x[2-1]+b[3-1]*x[1-1]-a[2-1]*y[2-1]-a[3-1]*y[1-1]
    y[4-1]=b[1-1]*x[4-1]+b[2-1]*x[3-1]+b[3-1]*x[2-1]+b[4-1]*x[1-1]-a[2-1]*y[3-1]-a[3-1]*y[2-1]-a[4-1]*y[1-1]
    for m in xrange(4,len(x)):
        y[m]=b[1-1]*x[m]+b[2-1]*x[m-1]+b[n-2-1]*x[m-2]+b[n-1-1]*x[m-3]+b[n-1]*x[m-4]-a[n-1]*y[m-4]-a[n-1-1]*y[m-3]-a[n-2-1]*y[m-2]-a[2-1]*y[m-1]    
    i_mat[:,jj] = y[range(int(start),int(stop),int(downsample))]
    jj+=1
    
    #save results

with open(os.getcwd()+'/output.txt','w') as f:
    f.write('time (ms)\t')
    for sec in secs:
        f.write('{0}(0.5)\t'.format(sec.name()))
    f.write('\n')
    for i in xrange(len(t)):
        f.write('{0}\t'.format(t[i]))
        for j in xrange(len(secs)):
            f.write('{0}\t'.format(i_mat[i,j]))
        f.write('\n')

with open(os.getcwd()+'/coords.txt','w') as g:
    for sec in secs:
        g.write('{0}(0.5)\t'.format(sec.name()))
    for i in range(0,3):
        g.write('\n')        
        for sec in secs:
            g.write('{0}\t'.format(cell.center_3Dcoords(sec)[i]))



# s = struct.pack('d'*len(testnumbers), *testnumbers)
# out_file.write(s)
# out_file.close()


