/* Created by Language version: 6.2.0 */
/* NOT VECTORIZED */
#include <stdio.h>
#include <math.h>
#include "scoplib.h"
#undef PI
 
#include "md1redef.h"
#include "section.h"
#include "md2redef.h"

#if METHOD3
extern int _method3;
#endif

#undef exp
#define exp hoc_Exp
extern double hoc_Exp();
 
#define _threadargscomma_ /**/
#define _threadargs_ /**/
 	/*SUPPRESS 761*/
	/*SUPPRESS 762*/
	/*SUPPRESS 763*/
	/*SUPPRESS 765*/
	 extern double *getarg();
 static double *_p; static Datum *_ppvar;
 
#define t nrn_threads->_t
#define dt nrn_threads->_dt
#define gk _p[0]
#define ih _p[1]
#define f _p[2]
#define Df _p[3]
#define finf _p[4]
#define ftau _p[5]
#define _g _p[6]
 
#if MAC
#if !defined(v)
#define v _mlhv
#endif
#if !defined(h)
#define h _mlhh
#endif
#endif
 static int hoc_nrnpointerindex =  -1;
 /* external NEURON variables */
 extern double celsius;
 /* declaration of user functions */
 static int _hoc_setinf();
 static int _mechtype;
extern int nrn_get_mechtype();
 static _hoc_setdata() {
 Prop *_prop, *hoc_getdata_range();
 _prop = hoc_getdata_range(_mechtype);
 _p = _prop->param; _ppvar = _prop->dparam;
 ret(1.);
}
 /* connect user functions to hoc names */
 static IntFunc hoc_intfunc[] = {
 "setdata_Ih", _hoc_setdata,
 "setinf_Ih", _hoc_setinf,
 0, 0
};
 /* declare global and static user variables */
#define Q10 Q10_Ih
 double Q10 = 2;
#define activate_Q10 activate_Q10_Ih
 double activate_Q10 = 1;
#define eih eih_Ih
 double eih = -56.1105;
#define gmax_k gmax_k_Ih
 double gmax_k = 0;
#define gmaxQ10 gmaxQ10_Ih
 double gmaxQ10 = 2;
#define rate_k rate_k_Ih
 double rate_k = 0;
#define tempb tempb_Ih
 double tempb = 35.5;
#define temp2 temp2_Ih
 double temp2 = 35;
#define temp1 temp1_Ih
 double temp1 = 25;
#define usetable usetable_Ih
 double usetable = 1;
 /* some parameters have upper and lower limits */
 static HocParmLimits _hoc_parm_limits[] = {
 "usetable_Ih", 0, 1,
 0,0,0
};
 static HocParmUnits _hoc_parm_units[] = {
 "eih_Ih", "mV",
 "temp1_Ih", "degC",
 "temp2_Ih", "degC",
 "tempb_Ih", "degC",
 "gk_Ih", "mho/cm2",
 "ih_Ih", "mA/cm2",
 0,0
};
 static double delta_t = 1;
 static double f0 = 0;
 static double v = 0;
 /* connect global user variables to hoc */
 static DoubScal hoc_scdoub[] = {
 "eih_Ih", &eih_Ih,
 "activate_Q10_Ih", &activate_Q10_Ih,
 "Q10_Ih", &Q10_Ih,
 "gmaxQ10_Ih", &gmaxQ10_Ih,
 "temp1_Ih", &temp1_Ih,
 "temp2_Ih", &temp2_Ih,
 "tempb_Ih", &tempb_Ih,
 "rate_k_Ih", &rate_k_Ih,
 "gmax_k_Ih", &gmax_k_Ih,
 "usetable_Ih", &usetable_Ih,
 0,0
};
 static DoubVec hoc_vdoub[] = {
 0,0,0
};
 static double _sav_indep;
 static void nrn_alloc(), nrn_init(), nrn_state();
 static void nrn_cur(), nrn_jacob();
 
static int _ode_count(), _ode_map(), _ode_spec(), _ode_matsol();
 
#define _cvode_ieq _ppvar[0]._i
 /* connect range variables in _p that hoc is supposed to know about */
 static char *_mechanism[] = {
 "6.2.0",
"Ih",
 "gk_Ih",
 0,
 "ih_Ih",
 0,
 "f_Ih",
 0,
 0};
 
static void nrn_alloc(_prop)
	Prop *_prop;
{
	Prop *prop_ion, *need_memb();
	double *_p; Datum *_ppvar;
 	_p = nrn_prop_data_alloc(_mechtype, 7, _prop);
 	/*initialize range parameters*/
 	gk = 0.001;
 	_prop->param = _p;
 	_prop->param_size = 7;
 	_ppvar = nrn_prop_datum_alloc(_mechtype, 1, _prop);
 	_prop->dparam = _ppvar;
 	/*connect ionic variables to this model*/
 
}
 static _initlists();
  /* some states have an absolute tolerance */
 static Symbol** _atollist;
 static HocStateTolerance _hoc_state_tol[] = {
 0,0
};
 _Ih_reg() {
	int _vectorized = 0;
  _initlists();
 	register_mech(_mechanism, nrn_alloc,nrn_cur, nrn_jacob, nrn_state, nrn_init, hoc_nrnpointerindex, 0);
 _mechtype = nrn_get_mechtype(_mechanism[1]);
  hoc_register_dparam_size(_mechtype, 1);
 	hoc_register_cvode(_mechtype, _ode_count, _ode_map, _ode_spec, _ode_matsol);
 	hoc_register_tolerance(_mechtype, _hoc_state_tol, &_atollist);
 	hoc_register_var(hoc_scdoub, hoc_vdoub, hoc_intfunc);
 	ivoc_help("help ?1 Ih /Users/install/Projects/DBS LFP Recordings/STN Cell Model/PythonNeuron/simfiles/cells/umac/Ih.mod\n");
 hoc_register_limits(_mechtype, _hoc_parm_limits);
 hoc_register_units(_mechtype, _hoc_parm_units);
 }
 static double *_t_finf;
 static double *_t_ftau;
static int _reset;
static char *modelname = "Potassium Ih channel for STh";

static int error;
static int _ninits = 0;
static int _match_recurse=1;
static _modl_cleanup(){ _match_recurse=1;}
static _f_setinf();
static setinf();
 
static int _ode_spec1(), _ode_matsol1();
 static _n_setinf();
 static int _slist1[1], _dlist1[1];
 static int integrate();
 
/*CVODE*/
 static int _ode_spec1 () {_reset=0;
 {
   setinf ( _threadargscomma_ v ) ;
   Df = ( finf - f ) / ftau ;
   }
 return _reset;
}
 static int _ode_matsol1 () {
 setinf ( _threadargscomma_ v ) ;
 Df = Df  / (1. - dt*( ( ( ( - 1.0 ) ) ) / ftau )) ;
}
 /*END CVODE*/
 static int integrate () {_reset=0;
 {
   setinf ( _threadargscomma_ v ) ;
    f = f + (1. - exp(dt*(( ( ( - 1.0 ) ) ) / ftau)))*(- ( ( ( finf ) ) / ftau ) / ( ( ( ( - 1.0) ) ) / ftau ) - f) ;
   }
  return 0;
}
 static double _mfac_setinf, _tmin_setinf;
 static _check_setinf();
 static _check_setinf() {
  static int _maktable=1; int _i, _j, _ix = 0;
  double _xi, _tmax;
  static double _sav_celsius;
  if (!usetable) {return;}
  if (_sav_celsius != celsius) { _maktable = 1;}
  if (_maktable) { double _x, _dx; _maktable=0;
   _tmin_setinf =  - 100.0 ;
   _tmax =  100.0 ;
   _dx = (_tmax - _tmin_setinf)/400.; _mfac_setinf = 1./_dx;
   for (_i=0, _x=_tmin_setinf; _i < 401; _x += _dx, _i++) {
    _f_setinf(_x);
    _t_finf[_i] = finf;
    _t_ftau[_i] = ftau;
   }
   _sav_celsius = celsius;
  }
 }

 static setinf(double _lv){ _check_setinf();
 _n_setinf(_lv);
 return;
 }

 static _n_setinf(double _lv){ int _i, _j;
 double _xi, _theta;
 if (!usetable) {
 _f_setinf(_lv); return; 
}
 _xi = _mfac_setinf * (_lv - _tmin_setinf);
 _i = (int) _xi;
 if (_xi <= 0.) {
 finf = _t_finf[0];
 ftau = _t_ftau[0];
 return; }
 if (_i >= 400) {
 finf = _t_finf[400];
 ftau = _t_ftau[400];
 return; }
 _theta = _xi - (double)_i;
 finf = _t_finf[_i] + _theta*(_t_finf[_i+1] - _t_finf[_i]);
 ftau = _t_ftau[_i] + _theta*(_t_ftau[_i+1] - _t_ftau[_i]);
 }

 
static int  _f_setinf (  _lv )  
	double _lv ;
 {
   finf = 1.0 / ( 1.0 + exp ( ( _lv + 80.0 ) / 5.5 ) ) ;
   ftau = ( 1.0 / ( exp ( - 15.02 - 0.086 * _lv ) + exp ( - 1.5195 + 0.0701 * _lv ) ) ) / rate_k ;
    return 0; }
 
static int _hoc_setinf() {
  double _r;
    _r = 1.;
 setinf (  *getarg(1) ) ;
 ret(_r);
}
 
static int _ode_count(_type) int _type;{ return 1;}
 
static int _ode_spec(_NrnThread* _nt, _Memb_list* _ml, int _type) {
   Datum* _thread;
   Node* _nd; double _v; int _iml, _cntml;
  _cntml = _ml->_nodecount;
  _thread = _ml->_thread;
  for (_iml = 0; _iml < _cntml; ++_iml) {
    _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
    _nd = _ml->_nodelist[_iml];
    v = NODEV(_nd);
     _ode_spec1 ();
 }}
 
static int _ode_map(_ieq, _pv, _pvdot, _pp, _ppd, _atol, _type) int _ieq, _type; double** _pv, **_pvdot, *_pp, *_atol; Datum* _ppd; { 
 	int _i; _p = _pp; _ppvar = _ppd;
	_cvode_ieq = _ieq;
	for (_i=0; _i < 1; ++_i) {
		_pv[_i] = _pp + _slist1[_i];  _pvdot[_i] = _pp + _dlist1[_i];
		_cvode_abstol(_atollist, _atol, _i);
	}
 }
 
static int _ode_matsol(_NrnThread* _nt, _Memb_list* _ml, int _type) {
   Datum* _thread;
   Node* _nd; double _v; int _iml, _cntml;
  _cntml = _ml->_nodecount;
  _thread = _ml->_thread;
  for (_iml = 0; _iml < _cntml; ++_iml) {
    _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
    _nd = _ml->_nodelist[_iml];
    v = NODEV(_nd);
 _ode_matsol1 ();
 }}

static void initmodel() {
  int _i; double _save;_ninits++;
 _save = t;
 t = 0.0;
{
  f = f0;
 {
   double _lktemp , _lktempb , _lktemp1 , _lktemp2 ;
 if ( activate_Q10 > 0.0 ) {
     _lktemp = celsius + 273.0 ;
     _lktempb = tempb + 273.0 ;
     _lktemp1 = temp1 + 273.0 ;
     _lktemp2 = temp2 + 273.0 ;
     rate_k = exp ( log ( Q10 ) * ( ( 1.0 / _lktempb ) - ( 1.0 / _lktemp ) ) / ( ( 1.0 / _lktemp1 ) - ( 1.0 / _lktemp2 ) ) ) ;
     gmax_k = exp ( log ( gmaxQ10 ) * ( ( 1.0 / _lktempb ) - ( 1.0 / _lktemp ) ) / ( ( 1.0 / _lktemp1 ) - ( 1.0 / _lktemp2 ) ) ) ;
     }
   else {
     rate_k = 1.0 ;
     gmax_k = 1.0 ;
     }
   setinf ( _threadargscomma_ v ) ;
   f = finf ;
   }
  _sav_indep = t; t = _save;

}
}

static void nrn_init(_NrnThread* _nt, _Memb_list* _ml, int _type){
Node *_nd; double _v; int* _ni; int _iml, _cntml;
#if CACHEVEC
    _ni = _ml->_nodeindices;
#endif
_cntml = _ml->_nodecount;
for (_iml = 0; _iml < _cntml; ++_iml) {
 _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
#if CACHEVEC
  if (use_cachevec) {
    _v = VEC_V(_ni[_iml]);
  }else
#endif
  {
    _nd = _ml->_nodelist[_iml];
    _v = NODEV(_nd);
  }
 v = _v;
 initmodel();
}}

static double _nrn_current(double _v){double _current=0.;v=_v;{ {
   ih = ( gk * gmax_k ) * f * ( v - eih ) ;
   }
 _current += ih;

} return _current;
}

static void nrn_cur(_NrnThread* _nt, _Memb_list* _ml, int _type){
Node *_nd; int* _ni; double _rhs, _v; int _iml, _cntml;
#if CACHEVEC
    _ni = _ml->_nodeindices;
#endif
_cntml = _ml->_nodecount;
for (_iml = 0; _iml < _cntml; ++_iml) {
 _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
#if CACHEVEC
  if (use_cachevec) {
    _v = VEC_V(_ni[_iml]);
  }else
#endif
  {
    _nd = _ml->_nodelist[_iml];
    _v = NODEV(_nd);
  }
 _g = _nrn_current(_v + .001);
 	{ _rhs = _nrn_current(_v);
 	}
 _g = (_g - _rhs)/.001;
#if CACHEVEC
  if (use_cachevec) {
	VEC_RHS(_ni[_iml]) -= _rhs;
  }else
#endif
  {
	NODERHS(_nd) -= _rhs;
  }
 
}}

static void nrn_jacob(_NrnThread* _nt, _Memb_list* _ml, int _type){
Node *_nd; int* _ni; int _iml, _cntml;
#if CACHEVEC
    _ni = _ml->_nodeindices;
#endif
_cntml = _ml->_nodecount;
for (_iml = 0; _iml < _cntml; ++_iml) {
 _p = _ml->_data[_iml];
#if CACHEVEC
  if (use_cachevec) {
	VEC_D(_ni[_iml]) += _g;
  }else
#endif
  {
     _nd = _ml->_nodelist[_iml];
	NODED(_nd) += _g;
  }
 
}}

static void nrn_state(_NrnThread* _nt, _Memb_list* _ml, int _type){
 double _break, _save;
Node *_nd; double _v; int* _ni; int _iml, _cntml;
#if CACHEVEC
    _ni = _ml->_nodeindices;
#endif
_cntml = _ml->_nodecount;
for (_iml = 0; _iml < _cntml; ++_iml) {
 _p = _ml->_data[_iml]; _ppvar = _ml->_pdata[_iml];
 _nd = _ml->_nodelist[_iml];
#if CACHEVEC
  if (use_cachevec) {
    _v = VEC_V(_ni[_iml]);
  }else
#endif
  {
    _nd = _ml->_nodelist[_iml];
    _v = NODEV(_nd);
  }
 _break = t + .5*dt; _save = t;
 v=_v;
{
 { {
 for (; t < _break; t += dt) {
 error =  integrate();
 if(error){fprintf(stderr,"at line 64 in file Ih.mod:\n	SOLVE integrate METHOD cnexp\n"); nrn_complain(_p); abort_run(error);}
 
}}
 t = _save;
 }}}

}

static terminal(){}

static _initlists() {
 int _i; static int _first = 1;
  if (!_first) return;
 _slist1[0] = &(f) - _p;  _dlist1[0] = &(Df) - _p;
   _t_finf = makevector(401*sizeof(double));
   _t_ftau = makevector(401*sizeof(double));
_first = 0;
}
