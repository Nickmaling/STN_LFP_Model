from neuron import h
h.load_file("stdrun.hoc")

class Synapse(object):
    '''
    A mechanism of synaptic input into a model cell
    '''
    def __init__(self,location=None,**kwargs):

        self.variables = kwargs #possible variables to define

        #check that the synapse location is specified
        if not location:
            raise TypeError("Must specify a location for synaptic input...")
        self.location = location

        #-----------------------------------------------------------------------
        # Construct synapse
        #-----------------------------------------------------------------------
        self._construct_synapse()

    def __str__(self):
        return "General synaptic mechanism"
    def __del__(self):
        pass
    def __info__(self):
        pass

    def _construct_synapse(self):
        """ Choose synapse type """
        raise "Dummy synapse"

        #figure out a way to define the location of the synapse so that it
        #doesn't have to be at the center of the section (i.e. h.sec(0.5))

    #define vectors to "play" input times
    def VecStim(self,syntimes):
        self.vs = h.VecStim()

        self.syntimes = h.Vector(syntimes)  #times for synpatic inputs

        self.vs.play(self.syntimes) #"play" synapse times

        self.nc = h.NetCon(self.vs,self.synapse)    #define the synaptic connection
        self.nc.weight[0] = self.nc_weight
        self.nc.delay = self.nc_delay

    #define stimulation times using the NetStim mechanism
    def NetStim(self,delta_syn,tstart,nsyninputs,noise = 0.0):
        self.delta_syn = delta_syn
        self.tstart = tstart
        self.nsyninputs = nsyninputs
        self.noise = noise
        
        self.ns = h.NetStim(0.5)
        self.ns.interval = delta_syn
        self.ns.number = nsyninputs
        self.ns.start = tstart
        self.ns.noise = noise

        self.nc = h.NetCon(self.ns,self.synapse)    #define the synaptic connection
        self.nc.weight[0] = self.nc_weight
        self.nc.delay = self.nc_delay

    #make setting and getting variables/attributes scalable
    def set_variable(self,k,v):
        self.variables[k] = v
        #k = key, v = value
        
    def get_variable(self,k):
        return self.variables.get(k,None)



class Exp2Syn(Synapse):
    def __init__(self,location=None):
        super(Exp2Syn,self).__init__(location)
    def __str__(self):
        return "Exp2Syn"
    def _construct_synapse(self):     
        self.synapse = h.Exp2Syn(0.5,sec=self.location)

class sAMPA(Exp2Syn):
    """
    Exp2Syn synaptic mechanism with the properties of AMPA:

        Parameters are from Baufreton et al., 2005 J. Neurosci.
        i = G * (v-e)    i (nanoamps), g (uS);
        G = weight * factor * (exp(-t/tau2) - exp(-t/tau1))
        The weight is specified by the 'weight' field of a 'NetCon' object.
        The factor is defined so that the normalized peak is 1

        Called sAMPA because it is the resulting PSP at the soma
    """
    def __init__(self,location=None):
        super(sAMPA,self).__init__(location)
        
        #define the parameters of the Exp2Syn mechanism and the NetCon object
        self.synapse.tau1 = 0.8     #ms, rise time constant
        self.synapse.tau2 = 3.7     #ms, decay time constant
        self.synapse.e = 0.0        #mV, reversal potential
        #self.synapse.i             #nA, synaptic current
        self.g_peak = 0.0025        #uS, peak conductance
        self.fudge_weight = 1.5     #fudge factor to multiply the synaptic weights, 
                                #the weights were determined experimentally for rat STN cells in vitro
        self.nc_weight = self.g_peak*self.fudge_weight
        self.nc_delay = 0
        
class sGABAa(Exp2Syn):
    """
    Exp2Syn synaptic mechanism with the properties of GABAa:

        Parameters are from Baufreton et al., 2005 J. Neurosci.
        i = G * (v-e)    i (nanoamps), g (uS);
        G = weight * factor * (exp(-t/tau2) - exp(-t/tau1))
        The weight is specified by the 'weight' field of a 'NetCon' object.
        The factor is defined so that the normalized peak is 1

        Called sGABAa because it is the resulting PSP at the soma
    """
    def __init__(self,location=None):
        super(sGABAa,self).__init__(location)

        #define the parameters of the Exp2Syn mechanism and the NetCon object
        self.synapse.tau1 = 0.8     #ms, rise time constant
        self.synapse.tau2 = 10.0    #ms, decay time constant
        self.synapse.e = -80.0      #mV, reversal potential
        #self.synapse.i             #nA, synaptic current
        self.g_peak = 0.005         #uS, peak conductance
        self.fudge_weight = 1.5     #fudge factor to multiply the synaptic weights, 
                                #the weights were determined experimentally for rat STN cells in vitro
        self.nc_weight = self.g_peak*self.fudge_weight
        self.nc_delay = 0

class AMPA(Synapse):
    '''
        Minimal kinetic model for glutamate AMPA receptors

        Driven with NetCon object

        Saturating synapse, no "refractory" period for subsequent synpatic inputs

        Parameters (defaults given below):

            Cmax	= 1	(mM)		: max transmitter concentration
            Cdur	= 1	(ms)		: transmitter duration (rising phase)
            Alpha	= 1.1	(/ms mM)	: forward (binding) rate
            Beta	= 0.19	(/ms)		: backward (unbinding) rate
            Erev	= 0	(mV)		: reversal potential
            gmax		(umho)		: maximum conductance
    '''

    def __init__(self,location=None):
        super(AMPA,self).__init__(location)

        #define the parameters of the AMPA synapse and the NetCon object
        self.synapse.gmax = 0.0005  #uS, peak conductance
        self.fudge_weight = 1.0     #scaling (fudge) factor to weight the synaptic inputs

        self.nc_weight = self.synapse.gmax * self.fudge_weight
        self.nc_delay = 0

    def __str__(self):
        return "AMPA"

    def _construct_synapse(self):     
        self.synapse = h.AMPA(0.5,sec=self.location)

class NMDA(Synapse):
    '''
        Minimal kinetic model for glutamate NMDA receptors

        Driven with NetCon object

        Saturating synapse, no "refractory" period for subsequent synpatic inputs

        Parameters (defaults given below):

            Cmax	= 1	(mM)		: max transmitter concentration
            Cdur	= 1	(ms)		: transmitter duration (rising phase)
            Alpha	= 0.072	(/ms mM)	: forward (binding) rate
            Beta	= 0.0066(/ms)		: backward (unbinding) rate
            Erev	= 0	(mV)		: reversal potential
            gmax		(umho)		: maximum conductance
    '''

    def __init__(self,location=None):
        super(NMDA,self).__init__(location)

        #define the parameters of the NMDA synapse and the NetCon object
        self.synapse.gmax = 0.0001  #uS, peak conductance
        self.fudge_weight = 1.0     #scaling (fudge) factor to weight the synaptic inputs

        self.nc_weight = self.synapse.gmax * self.fudge_weight
        self.nc_delay = 0

    def __str__(self):
        return "NMDA"

    def _construct_synapse(self):     
        self.synapse = h.NMDA(0.5,sec=self.location)

class GABAa(Synapse):
    '''
        Minimal kinetic model for GABA-A receptors

        Driven with NetCon object

        Saturating synapse, no "refractory" period for subsequent synpatic inputs

        Parameters (defaults given below):

            Cmax	= 1	(mM)		: max transmitter concentration
            Cdur	= 1	(ms)		: transmitter duration (rising phase)
            Alpha	= 5	(/ms mM)	: forward (binding) rate
            Beta	= 0.18	(/ms)		: backward (unbinding) rate
            Erev	= -80	(mV)		: reversal potential
            gmax		(umho)		: maximum conductance
    '''
    
    def __init__(self,location=None):
        super(GABAa,self).__init__(location)

        #define the parameters of the AMPA synapse and the NetCon object
        self.synapse.gmax = 0.0005   #uS, peak conductance
        self.fudge_weight = 1.0     #scaling (fudge) factor to weight the synaptic inputs

        self.nc_weight = self.synapse.gmax * self.fudge_weight
        self.nc_delay = 0

    def __str__(self):
        return "GABAa"

    def _construct_synapse(self):     
        self.synapse = h.GABAa(0.5,sec=self.location)

def sec_rtype(cell,root_sec,dist_from_soma):
    """
        Function for assinging receptor types to the appropriate sections

        isecs,esecs = sec_rtype(cell,root_sec,dist_from_soma)

        isecs = list of sections to be assigned inhibitory receptors
        esecs = list of section to be assigned excitatory receptors

        cell = object of class "Cell"
        root_sec = "root" section of cell, (i.e. origin), distance calculations
                    will be performed relative to this section
        distance_from_soma (um) = distance parameter to divide inhibitory and excitatory sections
                (If the center of a section is less thand or equal to distance_from_soma
                away from the root_sec, then it will be inhibitory.  If farther away, will
                be excitatory.)

        NOTE: Only assigns receptors to sections with the name 'soma' or 'dend'
    """
    from numpy import sqrt
    esecs,isecs = list(),list()
    soma_coords = cell.center_3Dcoords(root_sec)
    secs = cell.get_secs()
    for sec in secs:
        coords = cell.center_3Dcoords(sec)

        dist = sqrt((coords[0] - soma_coords[0])**2 + \
                    (coords[1] - soma_coords[1])**2 + \
                    (coords[2] - soma_coords[2])**2)

        sec_type = ''.join([c for c in sec.name() if c.isalpha()])

        if (dist <= 100) and (sec_type == 'dend' or sec_type == 'soma'):
            isecs.append(sec)
        elif (sec_type == 'dend' or sec_type == 'soma'):
            esecs.append(sec)
        else:
            pass

    return isecs,esecs
    
