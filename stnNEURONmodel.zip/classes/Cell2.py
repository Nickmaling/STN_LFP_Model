from neuron import h
import neuron as nrn
h.load_file("stdrun.hoc")

class Cell(object):

    def __init__(self):

        nrn.NRN_NMODL_PATH=self.CELL_DIR
        #nrn.load_mechanisms(nrn.NRN_NMODL_PATH)

        self._construct_cell()


class STN(Cell):

    def __init__(self):
        import os
        self.CELL_DIR = os.getcwd() + '/cells/'
        self.CELL_NAME = "n17_full9_fem_type4RD_Gillies_10nodesOnly.hoc"

        super(STN,self).__init__()

     
    def _construct_cell(self):
        """ subthalamic nucleus projection neuron """
        h.load_file(self.CELL_DIR+self.CELL_NAME)
        self.root = h.soma[1]
