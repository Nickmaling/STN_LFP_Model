def rotate_xyz(theta,xyzin):
    '''
    Rotate NEURON coordinates about each axis in the specified manner

        'theta' is [theta_x,theta_y,theta_z], the amount to rotate about each axis in radians

        'xyzin' is the original [x,y,z] coordinates
        
        'about_' is the rotation in radians about the _-axis

        'out' is the new [x,y,z]
    '''

    from numpy import array,cos,sin,dot

    theta=array(theta)
    xyzin=array(xyzin)

    aboutx = theta[0]
    abouty = theta[1]
    aboutz = theta[2]

    #Rotation Matrices
    xrot = ([[1,0,0],[0,cos(aboutx),-sin(aboutx)],[0,sin(aboutx),cos(aboutx)]]) #rotate about x-axis
    yrot =([[cos(abouty),0,sin(abouty)],[0,1,0],[-sin(abouty),0,cos(abouty)]])    #rotate about y-axis
    zrot =([[cos(aboutz),-sin(aboutz),0],[sin(aboutz),cos(aboutz),0],[0,0,1]])    #rotate about z-axis

    out = xyzin

    #Turn 'out' so it matches the required orientation for matix multiplication

    #Rotations
    out = dot(xrot,out.T)
    out = dot(yrot,out)
    out = dot(zrot,out)
    out = out.T

    return out
